#CIS261
#Your Name
#Week 3 Library Book Tracker

from datetime import datetime

def display_welcome():
    today = datetime.now()
    date_string = today.strftime("%Y-%m-%d")
    print("=" * 50)
    print("Library Book Return System")
    print(f"Date: {date_string}")
    print("=" * 50)
    print("Instructions:")
    print("-Enter book information when prompted.")
    print("-Type ESC to end book return process when finished.")
    print("-Late fee: $0.25 per day after 14 days")
    print("-Damage fees: Good-$0, Fair-$5, Damaged-$15")
    print("=" * 50)   

def get_book_info():
    print("\n---Enter Book Return Information---")
    title = input("Book title (or type 'ESC' to finish):  ")
    if title.upper() == "ESC":
        return "ESC", "", 0, ""
    borrower = input("borrower name:  ")
    days = int(input("days borrower:  "))
    print("condition option: Good, Fair, Damaged")
    condition = input("Book condition:  ")
    return title, borrower, days, condition

def calculate_fees(days_borrowed, condition):
    late_fee = 0.0
    damage_fee = 0.0
    if days_borrowed > 14:
        late_days = days_borrowed - 14
        late_fee = late_days * 0.25
    if condition == "Good":
        damage_fee = 0.0
    elif condition == "Fair":
        damage_fee = 5.0
    elif condition == "Damaged":
        damage_fee = 15.0
    total_fee = late_fee + damage_fee
    return total_fee

def display_che3ckout(title, borrower, days, condition, fee):
    today = datetime.now()
    date_string = today.strftime("%m/%d/%Y")
    print ("\n" + "=" * 50)
    print("CHECKOUT PROCESSED")
    print(f"Date: {date_string}")
    print("=" * 50)
    print(f"Book TiTle: {title}")
    print(f"Borrower: {borrower}")
    print(f"Days Borrowed: {days}")
    print(f"Total Fee: ${fee:.2f}")
    print("=" *50)
    print("book return recorded successfully!\n")

def display_summary(total_books, total_fees, avarage_fee, highest_fee, lowest_fee):
    today = datetime.now()
    date_string = today.strftime("%/%d/%Y")
    print("\n")
    print("=" * 50)
    print("END OF DAY SUMMERY")
    print(f"Date: {date_string}")
    print("=" * 50)
    print(f"Total Book Processed: {total_books}")
    print(f"Total Fees Collected: ${total_fees:.2f}")
    print(f"Avarage Fee per Book: ${avarage_fee:.2f}")
    print(f"Highest Fee Charged:  ${highest_fee:.2f}")
    print(f"Lowest Fee Charged:   ${lowest_fee:.2f} ")
    print("=" * 50)
    print("Thank you for using the library Book Tracker!\n")

def display_all_checkouts(titles, borrowers, days_list, conditions, fees):
    print("=" * 50)
    print("All Book Checkouts - Detailed List")
    print("=" * 50)
    for i in range(len(titles)):
        print(f"\nCheckout #(i + 1):")
        print(f" Book:         {titles[i]}")
        print(f" Borrower:     {borrowers[i]}")
        print(f" Days:         {days_list[i]}")
        print(f" Condition:    {conditions[i]}")
        print(f" Fee:           ${fees[i]:.2f}")
    print("-" * 50)
     
def calculate_statistics(fees):
    if len(fees) == 0:
        return 0.0, 0.0, 0.0
    total_fees = sum(fees)
    average_fees = total_fees / len(fees)
    highest_fee = max(fees)
    lowest_fee = min(fees)
    return total_fees, average_fees, highest_fee, lowest_fee

def main():
    display_welcome()
    title = {}
    borrowers = {}
    days_list = {}
    condition = {}
    fees = {}
    dates = {}

    while True:
        title, borrower, days, condition = get_book_info()
        if title == "ESC":
            break
        fee = calculate_fees(days, condition)
        display_che3ckout(title, borrower, days, condition, fee)
        title.append(title)
        borrowers.append(borrower)
        days_list.append(days)
        condition.append(condition)
        fees.append(fee)
        dates.append(datetime.now())

    if len(title) > 0:
        display_all_checkouts(title, borrowers, days_list, condition, fees)
        total_fees, avarage_fees, highest_fee, lowest_fee = calculate_statistics(fees)
        display_summary(len(title), total_fees, avarage_fees, highest_fee, lowest_fee)
    else:
        print("\nNo books were processed today.")
main() 