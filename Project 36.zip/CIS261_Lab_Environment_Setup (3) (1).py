#Shawn Hubbard
#CIS261 Lab Environment Setup
#Week 1

def  hello_world():
     print("Hello World")
     hello_world()


