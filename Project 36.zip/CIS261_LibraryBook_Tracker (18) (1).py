# CIS261
# Morion Roxley
# Week 2 Library Book Tracker

from datetime import datetime

def display_welcome ():
    today = datetime.now()
    date_string=today.strftime("%Y-%m-%d")
    print ("=" *50)
    print ("Library Book Return System")
    print (f"Today's Date {date_string}")
    print ("=" * 50)
    print (" Instructions ")
    print ("- Enter book information when prompted")
    print ("- Type 'ESC' to end book return process when finished")
    print ("- Late fee $0.25 per day after 14 days")
    print ("- Damage fees: Good $0, Fair $5, Damaged $15")
    print ("="*50)

def get_book_info():
    print ("\n---Enter Book Return Information---")
    title = input("Book title (or type'ESC' to finish):  ")
    if title.upper() == "ESC":
        return "ESC", "", 0, ""
    borrower = input("Borrower Name:   ")
    days = int(input("Date Borrowed:   "))
    print("Condition Option: Good, Fair, Damaged")
    condition = input ("Book Condition:   ")
    return title, borrower, days, condition

def calculate_fees (days_borrowed, condition):
    late_fee = 0.0
    damaged_fee = 0.0
    if days_borrowed > 14:
        late_days = days_borrowed - 14
        late_fee = late_days * 0.25
    if condition == "Good":
        damaged_fee = 0.0
    elif condition == "Fair":
        damaged_fee = 5.0
    elif condition == "Damaged":
        damaged_fee = 15.0
    total_fee = late_fee + damaged_fee         
    return total_fee

def display_checkout (title, borrower, days, condition, fee):
    today = datetime.now()
    date_string = today.strftime("%m/%d/%Y")
    print ("/n" + "=" * 50)
    print ("CHECKOUT PROCESSED")
    print (f"Date:{date_string}")
    print ("/n" + "=" *50)
    print (f"Title: {title}")
    print (f"Borrower: {borrower} ")
    print (f"Days Borrowed: {days}")
    print (f"Fee: ${fee:.2f}")
    print ("=" * 50)
    print ("Book return recorded successfully!\n")

def display_summary (total_books, total_fees):
    today = datetime.now()
    date_string = today.strftime("%m/%d/%Y")
    print ("\n")
    print ("=" * 50) 
    print (" END OF DAY SUMMARY")
    print (f"Date: {date_string}")
    print ("=" * 50)
    print (f"Total books processed:{total_books}")
    print (f"Total fees collected {total_fees:.2f}")
    print ("=" *50)
    print ("Thank you for using the Library Book Tracker!")

def main():
    display_welcome()
    total_books = 0
    total_fees = 0.0
    while True:
        title, borrower, days, condition = get_book_info()
        if title == "ESC":
            break
        fee = calculate_fees(days, condition)
        display_checkout(title, borrower, days, condition, fee)
        total_books = total_books + 1
        total_fees = total_fees + fee
    if total_books > 0:
            display_summary(total_books, total_fees) 
    else:
            print("\nNo books processed today")
main()


