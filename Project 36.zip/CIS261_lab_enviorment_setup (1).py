#caleb Campbell
#CIS261 lab Enviorment Setup
#week 1
def hello_world():
 print("hello_world")

